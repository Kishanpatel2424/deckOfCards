package main.java.entity;

public enum Suit {
    HEARTS,
    DIAMONDS,
    CLUBS,
    SPADE
}
