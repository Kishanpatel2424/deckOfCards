**System Requirement**: Java 17

**Build the App**
1. Import into IntellijIde or Eclipse
2. Navigate to src/main/java.
3. Run DeckOfCardsApplication.java class

**Interact with the App**
Once the App is running, you can interact with command line using (start, deal, restart, quit) commands
1. Start: Starts new game and shuffles the card
2. deal; Dealt a card to the caller
3. Restart: Restarts the game
4. Quit: Exits the application
